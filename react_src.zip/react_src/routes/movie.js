var express = require('express');
var router = express.Router();
var m=require('../model/movies');
var mongoose=require('mongoose');

router.post('/add', function(req, res, next){

  var movie=new m()
    movie.Title=req.body.Title;
    movie.imdbID=req.body.imdbID;
    movie.Year=req.body.Year;
    movie.Poster=req.body.Poster;
    movie.save(function(err){
      if(err)
      {
        res.send(err);
      }
      else
      {
          res.send("Movie Inserted");
      }
    });
});

router.get('/display', function(req, res, next) {

  m.find({},function(err,docs){
    if(docs){
      res.json(docs);
    }
    else {
      res.send("error in display");
    }
  });
});

router.put('/update', function(req, res, next){

  var name=req.body;
  m.findOneAndUpdate({imdbID : req.body.imdbID},name,function(err){
    if(err)
    {
      res.send(err);
    }
    res.send("Movie Updated");
  });
});

router.delete('/delete', function(req, res, next){

  m.findOneAndRemove({
    imdbID : req.body.imdbID
  },function(err){
    if(err)
    {
      res.send(err);
    }
    res.send("Movie Deleted");
  });
});

module.exports = router;
