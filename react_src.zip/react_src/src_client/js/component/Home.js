var React=require('react');

var Home=React.createClass({

  render: function()
  {
    return(
      <div>
      <h2>  Welcome To Movie App!!! </h2>
      </div>
    );
}
});

module.exports=Home;
