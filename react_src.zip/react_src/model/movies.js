var mongoose=require("mongoose");
var Schema=mongoose.Schema;

var movies=new Schema({
  Title : String,
  imdbID : String,
  Year : String,
  Poster : String,
});

module.exports= mongoose.model('movies',movies);
